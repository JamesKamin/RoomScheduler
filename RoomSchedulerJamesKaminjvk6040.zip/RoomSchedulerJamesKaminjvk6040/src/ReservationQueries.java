

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jkenglish
 */
import java.sql.SQLException;

import java.util.ArrayList;

import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.Date;

import java.sql.Timestamp;

public class ReservationQueries {

    private static Connection connection;

    private static PreparedStatement addReservationEntry;

    private static ResultSet resultset;

    private static PreparedStatement getReservationEntryByFaculty;

    private static PreparedStatement cancelReservationEntry;

    private static PreparedStatement deleteReservationEntry;

    private static PreparedStatement getReservationEntryDate;

    private static PreparedStatement getRoomEntryByDate;

    public static ArrayList<ReservationEntry> getReservationsByDate(Date date) {
        connection = DBConnection.getConnection();
        ArrayList<ReservationEntry> reservation = new ArrayList<>();
        try {
            getReservationEntryDate = connection.prepareStatement("select faculty,room, seats, timestamp from reservations where date=? ");

            getReservationEntryDate.setDate(1, date);

            resultset = getReservationEntryDate.executeQuery();

            while (resultset.next()) {
                ReservationEntry reserve = new ReservationEntry(resultset.getString(1), resultset.getString(2), date, resultset.getInt(3), resultset.getTimestamp(4));

                reservation.add(reserve);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return reservation;

    }

    public static void addReservationEntry( String faculty,String room,Date date, int seats,  Timestamp timestamp) {
        connection = DBConnection.getConnection();
        try {
            addReservationEntry = connection.prepareStatement("insert into reservations (faculty,room,date,seats,timestamp) values (?,?,?,?,?)");
            addReservationEntry.setString(1, faculty);
            addReservationEntry.setString(2, room);
            addReservationEntry.setDate(3, date);
            addReservationEntry.setInt(4, seats);
            addReservationEntry.setTimestamp(5, timestamp);
            addReservationEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static int cancelReservationEntry(String faculty, Date date) {

        connection = DBConnection.getConnection();
        int count = 0;
        try {
            cancelReservationEntry = connection.prepareStatement("delete from reservations where faculty=? and date=? ");
            cancelReservationEntry.setString(1, faculty);
            cancelReservationEntry.setDate(2, date);
            count=cancelReservationEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
      return count;
    }

    public static ArrayList<ReservationEntry> getReservationsByFaculty(String faculty) {
        connection = DBConnection.getConnection();
        ArrayList<ReservationEntry> reservation = new ArrayList<>();
        try {
            getReservationEntryByFaculty = connection.prepareStatement("select faculty,room ,date, seats, timestamp from reservations where faculty =?");

            getReservationEntryByFaculty.setString(1, faculty);

            resultset = getReservationEntryByFaculty.executeQuery();

            while (resultset.next()) {
                ReservationEntry reserve = new ReservationEntry(faculty, resultset.getString(2), resultset.getDate(3), resultset.getInt(4), resultset.getTimestamp(5));

                reservation.add(reserve);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return reservation;

    }
    
    public static void deleteReservationEntry(String room) {

        connection = DBConnection.getConnection();
        try {
            deleteReservationEntry = connection.prepareStatement("delete from reservations where room=? ");
            deleteReservationEntry.setString(1, room);
            deleteReservationEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

    }
    
    
    

    public static ArrayList<String> getRoomsReservedByDate(Date date) {
        connection = DBConnection.getConnection();
        ArrayList<String> room1 = new ArrayList<>();
        try {
            getRoomEntryByDate = connection.prepareStatement("select room from reservations where date =?");

            getRoomEntryByDate.setDate(1, date);

            resultset = getRoomEntryByDate.executeQuery();

            while (resultset.next()) {

                room1.add(resultset.getString(1));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return room1;

    }
    
    public static ArrayList<ReservationEntry> getReservationsByRoom(String Room) {
        connection = DBConnection.getConnection();
        ArrayList<ReservationEntry> reservation = new ArrayList<>();
        try {
            getReservationEntryDate = connection.prepareStatement("select faculty,room,date, seats, timestamp from reservations where room=? ");

            getReservationEntryDate.setString(1, Room);

            resultset = getReservationEntryDate.executeQuery();

            while (resultset.next()) {
                ReservationEntry reserve = new ReservationEntry(resultset.getString(1), resultset.getString(2), resultset.getDate(3), resultset.getInt(4), resultset.getTimestamp(5));

                reservation.add(reserve);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return reservation;

    }

    
    
    
    

    

}
