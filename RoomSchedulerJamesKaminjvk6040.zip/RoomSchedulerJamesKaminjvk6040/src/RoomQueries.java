/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jkenglish
 */

import java.sql.Connection;


import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.ArrayList;

public class RoomQueries {
    
    private static Connection connection;
    
    private static PreparedStatement addRoom;
    
    private static PreparedStatement getallpossibleRoom;
    
    private static PreparedStatement dropRoom;
    
    private static ResultSet resultSet;
    
    public static ArrayList<String> getAllPossibleRooms(int seats)
    {
        connection = DBConnection.getConnection();
        ArrayList<String> rooms = new ArrayList<>();
        try
        {
            getallpossibleRoom = connection.prepareStatement("select name from room where seats>=? order by seats");
            getallpossibleRoom.setInt(1,seats);
            resultSet = getallpossibleRoom.executeQuery();
            
            while(resultSet.next())
            {
                
                
                rooms.add(resultSet.getString(1));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return rooms;
        
    }
    
    public static void addRoom(String room, int seats)
    {
        connection = DBConnection.getConnection();
        try
        {
            addRoom = connection.prepareStatement("insert into room (name,seats) values (?,?)");
            addRoom.setString(1, room);
            addRoom.setInt(2,seats);
            addRoom.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
    }
    
    public static void dropRoom(String room){
        
        connection = DBConnection.getConnection();
        try
        {
            dropRoom= connection.prepareStatement("delete from room where name=? ");
            dropRoom.setString(1,room);
            dropRoom.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
        
        
    }
    
}

