
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jkenglish
 */
public class WaitlistQueries {

    private static Connection connection;

    private static PreparedStatement addwaitlistEntry;

    private static PreparedStatement getwaitlistEntry;

    private static PreparedStatement getwaitlistbyDate;

    private static PreparedStatement getallwaitList;

    private static PreparedStatement getwaitlistbyFaculty;

    private static PreparedStatement deletewaitlistEntry;

    private static PreparedStatement cancelwaitlistEntry;

    private static ResultSet resultset;

    public static ArrayList<WaitlistEntry> getAllWaitList() {
        connection = DBConnection.getConnection();
        ArrayList<WaitlistEntry> waitlist = new ArrayList<>();
        try {
            getallwaitList = connection.prepareStatement("select faculty,date, seats, timestamp from waitlist");

            resultset = getallwaitList.executeQuery();

            while (resultset.next()) {
                WaitlistEntry entry = new WaitlistEntry(resultset.getString(1), resultset.getDate(2), resultset.getInt(3), resultset.getTimestamp(4));

                waitlist.add(entry);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return waitlist;

    }

    public static ArrayList<WaitlistEntry> getWaitListByDate(Date date) {
        connection = DBConnection.getConnection();
        ArrayList<WaitlistEntry> waitlistEntry = new ArrayList<>();
        try {
            getwaitlistbyDate = connection.prepareStatement("select faculty,date, seats, timestamp from waitlist");

           

            resultset = getwaitlistbyDate.executeQuery();

            while (resultset.next()) {
                WaitlistEntry entry = new WaitlistEntry(resultset.getString(1), resultset.getDate(2), resultset.getInt(3), resultset.getTimestamp(4));

                waitlistEntry.add(entry);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return waitlistEntry;

    }

    public static void addWaitListEntry( String faculty,Date date, int seats, Timestamp timestamp) {
        connection = DBConnection.getConnection();
        try {
            addwaitlistEntry = connection.prepareStatement("insert into waitlist (faculty,date,seats,timestamp) values (?,?,?,?)");
            addwaitlistEntry.setString(1, faculty);

            addwaitlistEntry.setDate(2, date);
            addwaitlistEntry.setInt(3, seats);
            addwaitlistEntry.setTimestamp(4, timestamp);
            addwaitlistEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

    }

    public static ArrayList<WaitlistEntry> getWaitListByFaculty(String faculty) {
        connection = DBConnection.getConnection();
        ArrayList<WaitlistEntry> waitlistEntry = new ArrayList<>();
        try {
            getwaitlistbyFaculty = connection.prepareStatement("select faculty,date, seats, timestamp from waitlist where faculty=?");

            getwaitlistbyFaculty.setString(1, faculty);

            resultset = getwaitlistbyFaculty.executeQuery();

            while (resultset.next()) {
                WaitlistEntry entry = new WaitlistEntry(faculty, resultset.getDate(2), resultset.getInt(3), resultset.getTimestamp(4));

                waitlistEntry.add(entry);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return waitlistEntry;

    }
    
    
    public static void deletewaitlistEntry(String room) {

        connection = DBConnection.getConnection();
        try {
            deletewaitlistEntry = connection.prepareStatement("delete from waitlist where room=? ");
            deletewaitlistEntry.setString(1, room);
            deletewaitlistEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

    }




    public static void cancelWaitListEntry(String faculty, Date date) {

        connection = DBConnection.getConnection();
        try {
            cancelwaitlistEntry = connection.prepareStatement("delete from waitlist where faculty=? and date=? ");
            cancelwaitlistEntry.setString(1, faculty);
            cancelwaitlistEntry.setDate(2, date);
            cancelwaitlistEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

    }

}


